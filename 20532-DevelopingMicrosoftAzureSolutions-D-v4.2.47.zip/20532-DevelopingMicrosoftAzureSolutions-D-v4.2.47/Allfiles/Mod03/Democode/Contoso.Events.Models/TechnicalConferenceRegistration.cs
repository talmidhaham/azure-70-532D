﻿namespace Contoso.Events.Models
{
    public class TechnicalConferenceRegistration : GeneralRegistration
    {
        public int NumberOfKeyFobs { get; set; }
    }
}