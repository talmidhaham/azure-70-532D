﻿namespace Contoso.Events.Models
{
    public class ApplicationSettings
    {
        public int LatestEventCount { get; set; }
    }
}