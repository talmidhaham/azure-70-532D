﻿namespace Contoso.Events.Models
{
    public enum SignInSheetState
    {
        NoSignInSheet = 0,
        SignInDocumentProcessing,
        SignInDocumentAlreadyExists
    }
}